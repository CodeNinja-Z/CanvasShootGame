Mario Invaders

Team:Sihan WU, 9998499931 and Zhoufeng Zheng, 998590564

1.The whole game is based on a canvas, we use its size to decide the position and movement of player and enemies.

2.We update the game by FPS, and randomly draw missiles from enemies.

3.We bind keys with game and use key-pressed events to control the game.

4.Enemy moves faster as it goes down, and shoot more often as levels up.

5.We used resources from the famous game Super Mario.

6.We reset the position of player when it reaches margin and that of enemies when they reaches bottom.

7.We planned to make multiple kind of enemies with different route of missiles and use 0-9 single images to draw different scores, but finnaly we gave up because we have to spend time on upcoming midterms...

